#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int i;
int j;
int mat1[3][3];
int mat2[6][7];
int vect[10];

void llenarMatriz1Rand(int mat[3][3]){
    for(i=0;i<3;i++){
        for(j=0;j<3;j++){
            mat[i][j] = rand()%200;
        }
    }
}

void printMatriz1(int mat[3][3]){
    for(i=0;i<3;i++){
        for(j=0;j<3;j++){
            printf("%d \n",mat[i][j]);
        }
    }
}

int mayorMatriz1(int mat[3][3]){
    int mayor=0;
    for (int i=0;i<3;i++) {
        for (int j=0;j<3;j++) {
            if (mat[i][j]>mayor) {
                mayor = mat[i][j];
            }
        }
    }
    return mayor;
}

void cargarMatriz2(int mat[6][7]){
    for(i=0;i<6;i++){
        for(j=0;j<7;j++){
            printf("ingrese numero: ");
            scanf("%d", &mat[i][j]);
        }
    }
}

void printMatriz2(int mat[6][7]){
    for(i=0;i<6;i++){
        for(j=0;j<7;j++){
            printf("%d \n",mat[i][j]);
        }
    }
}

void sumarMatriz2(int mat[6][7]){
    int suma;
    for(i=0;i<6;i++){//FILAS
        suma = 0;
        for(j=0;j<7;j++){
            suma += mat[i][j];//fila 1 col 1 2 3 4 5 6 7 fila 2 col 1 2 3 4 5 6 7
        }
        printf("Suma Fila %d: %d\n",i+1,suma);
    }
    for(i=0;i<7;i++){
        suma=0;
        for(j=0;j<6;j++){
            suma += mat[j][i];//col 1 fila 1 2 3 4 5 6
        }
        printf("Suma Columna %d: %d\n",i+1,suma);
    }
}

void cargarVector(int vect[10]){
    for(i=0;i<10;i++){
        vect[i]=rand()%200;
    }
}

void mostrarVector(int vect[10]){
    for(i=0;i<10;i++){
            printf("%d \n", vect[i]);
    }
}

void ordenarVector(int vect[10]){
    int hold =0;

    for(i=0;i<10;i++){
        for(j=i+1;j<10;j++){
            if(vect[i]<vect[j]){
                hold = vect[i];
                vect[i]=vect[j];
                vect[j]= hold;
            }
        }
    }
}

int mayorEnVector(int vect[10]){
    int mayor=0;
    for (int i=0;i<10;i++){
        if (mayor < vect[i]){
        mayor = vect[i];
        }
    }
    return mayor;
}


int main()
{
    llenarMatriz1Rand(mat1);
    printMatriz1(mat1);
    printf("Mayor numero en la primera matriz:%d\n", mayorMatriz1(mat1));

    cargarMatriz2(mat2);
    printMatriz2(mat2);
    sumarMatriz2(mat2);

    cargarVector(vect);
    printf("Vector Desordenado\n");
    mostrarVector(vect);
    ordenarVector(vect);
    printf("Vector Ordenado\n");
    mostrarVector(vect);
    printf("Mayor numero en el vector:%d\n",mayorEnVector(vect));



    return 0;
}
