﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practica_corte_de_control_unico_archivo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void leer()
        {
            FileStream fs = new FileStream("Empresas.csv", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            string line;
            string[] vector = new String[0];
            textBox1.Text += "Lista" + Environment.NewLine;
            line = sr.ReadLine();
            line = sr.ReadLine();

            vector = line.Split(';');
            int contadorEmpresa = 0;

            while (line != null)//while empresa
            {
                String empresa = vector[0];
                textBox1.Text += Environment.NewLine;
                textBox1.Text += "-------" + Environment.NewLine;
                textBox1.Text += "empresa" + Environment.NewLine;
                textBox1.Text += "-------" + Environment.NewLine;
                int contadorArea;
                while (line != null && empresa == vector[0]) {//while area

                    String area = vector[1];
                    textBox1.Text += Environment.NewLine;
                    textBox1.Text += "-------" + Environment.NewLine;
                    textBox1.Text += "empresa" + Environment.NewLine;
                    textBox1.Text += "-------" + Environment.NewLine;
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            leer();
        }
    }
}
