﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        int test = 0;
        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {

            MessageBox.Show("click " + test);
            if (test < 100) {
                if (checkBox1.Checked) {
                    test += 20;
                }
                else {
                    test += 10;
                }
            }
            else {
                test = 0;
            }
            progressBar1.Value = test;
            if (progressBar1.Value == 100)
            {
                checkBox2.Visible = true;
            }
            else
            {
                checkBox2.Visible = false;
            }

            if (checkBox2.Checked && !(this.Controls.ContainsKey("newLabel"))){
                CreateControl();
                Button newButton = new Button();
                newButton.Text = "test";
                newButton.Click += newButton_Click;
                this.Controls.Add(newButton);
            }
        }

        private void newButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("CLICKEADO");
            Controls.Clear();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                MessageBox.Show("seleccionado");
            }
            else
            {
                MessageBox.Show("ahora no");
            }
            
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            checkBox2.Visible=false;

        }
    }
 }
