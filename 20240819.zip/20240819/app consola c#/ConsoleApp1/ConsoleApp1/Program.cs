﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //sumar 2 valores
            /*int a;
            float b, c;

            a = 10;
            b = (float)30.5;
            c = (float)(a + b);
            Console.WriteLine("{0}+{1}={2}", a, b, c);
            Console.ReadKey();
            */



            //dos valores iguales
            /*int a, b;
            a = 1;
            b = 1;
            if (a == b){
                Console.WriteLine("iguales");
                Console.ReadLine();
            }
            else{
                Console.WriteLine("dif");
                Console.ReadLine();
            }*/

            //ingresar valor de hora y tiempo de trabajo, indicar sueldo
            /*string str;
            float valor, tiempo, total;

            Console.WriteLine("Indicar cantidad de horas trabajadas");
            str = Console.ReadLine();
            tiempo = Convert.ToInt32(str);

            Console.WriteLine("Ingresar valor de hora");
            str = Console.ReadLine();
            valor = Convert.ToInt32(str);

            total = valor*tiempo;
            Console.WriteLine("el sueldo es: {0}", total);
            Console.ReadLine();
            */

            //indicar si son iguales, y si dif indicar el menor
            /*int a, b;
            a = 1;
            b = 2;
            if (a == b){
                Console.WriteLine("iguales");
                Console.ReadLine();
            }
            else{
                Console.WriteLine("dif");
                if (a < b){
                    Console.WriteLine("a es menor");
                }
                else{
                    Console.WriteLine("b es menor");
                }
                Console.ReadLine();
             */


            //ingresar 4 valores y sumarlos
            /*string str;
            int i, total, a;
            total = 0;

            for(i=0; i<4; i++)
            {
                Console.WriteLine("ingrese valor ({0})",i);
                str = Console.ReadLine();
                a = Convert.ToInt32(str);
                total += a;
            }
            Console.WriteLine("la suma es {0}",total);
            Console.ReadKey();
            */

            //ingresar sueldos de empleados, sumarlos , indicar su valor promedio, finalizar con legajo = 0
            /*string str;
            int legajo, sueldo, total, cant;
            float prom;
            total = cant = 0;

            Console.WriteLine("ingresar legajo");
            str = Console.ReadLine();
            legajo = Convert.ToInt32(str);

            while (legajo != 0){
                Console.WriteLine("Ingrese sueldo");
                str = Console.ReadLine();
                sueldo = Convert.ToInt32(str);

                total = total + sueldo;
                cant++;

                Console.WriteLine("ingresar legajo");
                str = Console.ReadLine();
                legajo = Convert.ToInt32(str);
            }
            prom = (float)(total / cant);
            Console.WriteLine("el total pagado en sueldos es {0}", total);
            Console.WriteLine("el promedio de los sueldos es {0}", prom);
            Console.ReadKey();
            */

            /*ingresar el valor de la hs de cada categoría, guardarlo en 
            Un vector y luego ingresar los empleados de la empresa 
            Hasta legajo = 0, indicar el sueldo de cada empleado y el 
            Total a pagar 
            */

            /*string str;
            int[] vect = new int[5];
            int categoria, legajo, horas, i, sueldo, total;

            total = 0;
            for(i=0; i<5; i++){
                Console.WriteLine("ingrese valor de hora de categoria {0}",i+1);
                str = Console.ReadLine();
                vect[i]= Convert.ToInt32(str);
            }
            Console.WriteLine("ingresar legajo");
            str = Console.ReadLine();
            legajo = Convert.ToInt32(str);
            while (legajo != 0)
            {
                Console.WriteLine("ingrese numero de categoria");
                str = Console.ReadLine();
                categoria = Convert.ToInt32(str)-1;


                Console.WriteLine("ingrese numero de hs trabajadas");
                str = Console.ReadLine();
                horas = Convert.ToInt32(str);

                sueldo = horas * vect[categoria];
                Console.WriteLine("legajo {0} cobrara {1}", legajo, sueldo);

                total += sueldo;

                Console.WriteLine("ingresar legajo");
                str = Console.ReadLine();
                legajo = Convert.ToInt32(str);
            }
            Console.WriteLine("el total a pagar por sueldos es {0}", total);
            Console.ReadKey();
            */

            /*ingrese el valor de la hs de cada categoría   
            Indique el sueldo de cada empleado, la cantidad de empleados por categoría
            Valor total a pagar en calidad de sueldos*/

            string str;
            int[] vectCats = new int[5];
            int[] vectEmpleados = new int[5];

            int categoria, legajo, horas, i, sueldo, total;

            total = 0;
            for (i = 0; i < 5; i++)
            {
                Console.WriteLine("ingrese valor de hora de categoria {0}", i + 1);
                str = Console.ReadLine();
                vectCats[i] = Convert.ToInt32(str);
            }
            Console.WriteLine("ingresar legajo");
            str = Console.ReadLine();
            legajo = Convert.ToInt32(str);
            while (legajo != 0){
                Console.WriteLine("ingrese numero de categoria");
                str = Console.ReadLine();
                categoria = Convert.ToInt32(str) - 1;

                vectEmpleados[categoria] += 1;

                Console.WriteLine("ingrese numero de hs trabajadas");
                str = Console.ReadLine();
                horas = Convert.ToInt32(str);

                sueldo = horas * vectCats[categoria];
                Console.WriteLine("legajo {0} cobrara {1}", legajo, sueldo);

                total += sueldo;

                Console.WriteLine("ingresar legajo");
                str = Console.ReadLine();
                legajo = Convert.ToInt32(str);
            }
            Console.WriteLine("el total a pagar por sueldos es {0}", total);
            for(i=0;i<5;i++){
                Console.WriteLine("de la categoria {0} hay {1} empleados", i+1, vectEmpleados[i]);
            }

            Console.ReadKey();

        }
    }
}
