﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

        public string nueLi = Environment.NewLine;

        public Form1()
        {
            InitializeComponent();
        }

        private void escribe (string v)
        {
            textBox1.Text += v;
        }


        public void damePromedio(int legajo)
        {
            FileStream FS = new FileStream("Notas.csv", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(FS);

            string ln = "";
            string[] VLN = new string[0];
            ln = sr.ReadLine();
            ln = sr.ReadLine();
            VLN = ln.Split(';');
            int suma = 0;
            int cn = 0;
            while (ln != null)
            {
                if (legajo == Convert.ToInt32(VLN[0]))
                {
                    dameMateria(Convert.ToInt32(VLN[1]));
                    escribe(VLN[1]+""+nueLi);
                    suma += Convert.ToInt32(VLN[2]);
                    cn++;
                }

                ln = sr.ReadLine();
                if(ln != null)
                {
                    VLN = ln.Split(';');
                }
            }
        }

        private void dameMateria(int NUMAT)
        {
            FileStream FS = new FileStream("Materias.csv", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(FS);

            string lm = "";
            string[] VLM = new string[0];
            lm = sr.ReadLine();
            lm = sr.ReadLine();
            VLM = lm.Split(';');
            while(lm != null)
            {
                if (Convert.ToInt32(VLM[0]) == NUMAT)
                {
                    escribe("Materia: "+VLM[1]);
                    break;
                }
                lm = sr.ReadLine();
                if(lm != null)
                {
                    VLM = lm.Split(';');

                }
            }
            sr.Close();
            FS.Close();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            escribe("listado de alumnos"+nueLi);
            escribe("*******************************************"+nueLi);
            FileStream FS = new FileStream("Alumnos.csv", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(FS);

            string la = "";
            string[] VLA = new string[0];

            la = sr.ReadLine();//leer encabezados
            la = sr.ReadLine();

            VLA = la.Split(';');

            while (la != null)
            {
                escribe("Alumno: " + VLA[1] + "," + VLA[2] + "," + VLA[0]+nueLi);
                escribe("-------------------------------------------------------"+nueLi);
                int legajo = Convert.ToInt32(VLA[0]);
                damePromedio(legajo);
            }

        }
    }
}
