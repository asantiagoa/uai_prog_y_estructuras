﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Alumno_nota
{
    public partial class Form1 : Form
    {
        public string NueLi = Environment.NewLine;
       
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button1.Text = "Reporte de Alumnos";
        }



        public void DamePromedio(int lega)
        {
            FileStream FS = new FileStream("Notas.csv", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(FS);

            string ln = "";
            string[] VLN = new string[0];
            ln = sr.ReadLine();
            ln = sr.ReadLine();
            VLN = ln.Split(';');
            int suma = 0;
            int cn = 0;
            while(ln!=null)
            {
                if (lega == Convert.ToInt32( VLN[0]))
                {
                    DameMateria(Convert.ToInt32(VLN[1]));
                    escribe(VLN[1]+""+NueLi);
                    suma += Convert.ToInt32( VLN[2]);
                    cn++;

                }
                ln = sr.ReadLine();
                if (ln != null)
                { VLN = ln.Split(';'); }
            }
            escribe("Promedio: "+(suma / cn).ToString() + NueLi);
            escribe("==================================================" + NueLi);

            sr.Close();
            FS.Close();

        }
        
        
        public void DameMateria(int NM)
        {
            //leer archivo de materias
            FileStream FS = new FileStream("Materias.csv", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(FS);

            string la = "";
            string[] VLM = new string[0];
            la = sr.ReadLine();
            la = sr.ReadLine();
            VLM = la.Split(';');
            while (la!=null)
            {
                if (Convert.ToInt32( VLM[0])==NM)
                {
                    escribe("Materia: " + VLM[1]);
                    break;
                }
                la = sr.ReadLine();
                if (la != null)
                {
                    VLM = la.Split(';');
                }

            }




            sr.Close();
            FS.Close();
        }

        private void escribe(string v)
        {
            textBox1.Text += v;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //lee alumnos
            escribe("Listado de Alumnos con Notas y Promedios " +NueLi);
            escribe("****************************************************************" + NueLi+NueLi);
            escribe(NueLi);

            FileStream FS = new FileStream("Alumnos.csv", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(FS);

            string la = "";
            string[] VLA=new string[0];

            la=sr.ReadLine(); //encabezados
            la = sr.ReadLine();
            VLA = la.Split(';');
            while (la!=null)
            {
                escribe("Alumno: " + VLA[1] + ", " + VLA[2]+" - " + VLA[0]+NueLi);
                escribe("-----------------------------------------------"+NueLi);
              //  int mate =Convert.ToInt32( VLA[2]);
                int legajo = Convert.ToInt32( VLA[0]);
           //     DameMateria(mate);
                DamePromedio(legajo);
                
                la=sr.ReadLine() ;
                if(la!=null)
                {
                    VLA = la.Split(';');
                }
            }

            sr.Close();
            FS.Close();
        }
    }
}
