﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testlistas
{
    public partial class Form1 : Form
    {

        LinkedListSE Lista = new LinkedListSE();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(txtNombre.Text!="" && txtApellido.Text != "" && txtEdad.Text != "")
            {
                CLSPersona persona = new CLSPersona();
                persona.Nombre = txtNombre.Text;
                persona.Apellido = txtApellido.Text;
                persona.Edad = txtEdad.Text;

                Lista.Agregar(persona);
            }
            mostrarLista(listBox1);
        }

        private void mostrarLista(ListBox box)
        {
            box.Items.Clear();

            CLSPersona Actual = Lista.Primer;
            while (Actual.Sig != null)
            {
                box.Items.Add(Actual);
                Actual = Actual.Sig;
            }
            box.Items.Add(Actual);
        }

        private void btnInsPos_Click(object sender, EventArgs e)
        {
            if (txtNombre.Text != "" && txtApellido.Text != "" && txtEdad.Text != "" && txtPos.Text != "")
            {
                int pos = Int32.Parse(txtPos.Text);
                CLSPersona persona = new CLSPersona();
                persona.Nombre = txtNombre.Text;
                persona.Apellido = txtApellido.Text;
                persona.Edad = txtEdad.Text;

                Lista.InsertEnPos(persona, pos);
            }
            mostrarLista(listBox1);
        }
    }
}
