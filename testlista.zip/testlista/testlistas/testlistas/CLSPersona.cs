﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testlistas
{
    public class CLSPersona
    {
        public int Id;
        public string Nombre;
        public string Apellido;
        public string Edad;

        public CLSPersona Sig;

        public CLSPersona() { }


        //constructor
        public CLSPersona(string nombre, string apellido, string edad)
        {
            Id = 0;
            Nombre = nombre;
            Apellido = apellido;
            Edad = edad;

            Sig = null;
        }

        public override string ToString()
        {
            return Id + " " + Nombre + " " + Apellido + " " + Edad;
        }
    }
}
