﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/*
 * AGREGAR METODOS:
 * 1-Agregar Primero
 * 2-Agregar Último(r)
 * 3-Insertar en posicion especifica
 * 4-Borrar Primero
 * 5-Borrar Último
 * 6-Modificar posicion específica
 * */
namespace testlistas
{
    public  class LinkedListSE
    {
        public CLSPersona Primer;

        public void Agregar(CLSPersona Nuevo)
        {
            if(Primer== null)
            {
                Primer = Nuevo;
            }
            else
            {
                CLSPersona Actual = Primer;
                while(Actual.Sig != null)
                {
                    Actual = Actual.Sig;
                }
                Actual.Sig = Nuevo;
            }
        }

        public void InsertEnPos(CLSPersona Nuevo, int pos)
        {
            CLSPersona Actual = Primer;
            Actual.Sig = Nuevo;

            int i = 0;
            while(i<pos && Actual.Sig!= null)
            {
                Actual = Actual.Sig;
                i++;
            }
            Nuevo.Sig = Actual.Sig;
            Actual = Nuevo;
        }
    }
}
