﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arakelian_parcial_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void reporte()
        {
            FileStream fs = new FileStream("ProductosElectronica.csv", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);

            string ln;
            string[] vln = new string[0];
            textBox1.Text += "Reporte" + Environment.NewLine;

            ln = sr.ReadLine();
            ln = sr.ReadLine();

            vln = ln.Split(';');


            while (ln != null)
            {

                ln = sr.ReadLine();
                string categoria = vln[0];
                textBox1.Text += Environment.NewLine;
                textBox1.Text += "*********************************" + Environment.NewLine;
                textBox1.Text += "Categoria: " + categoria + Environment.NewLine;
                textBox1.Text += "*********************************" + Environment.NewLine;

                //string precio = vln[3];
                //string prod = vln[2];

                //textBox1.Text += prod + "-" + precio + Environment.NewLine;


                //ln = sr.ReadLine();
                while (ln != null && categoria == vln[0])
                {
                    string subcategoria = vln[1];
                    textBox1.Text += "--------------------" + Environment.NewLine;
                    textBox1.Text += "Subcategoria:" + subcategoria + Environment.NewLine;
                    textBox1.Text += "--------------------" + Environment.NewLine;

                    //ln = sr.ReadLine();
                    ln = sr.ReadLine();
                    string precio = vln[3];
                    string prod = vln[2];
                    textBox1.Text += prod + "-" + precio + Environment.NewLine;

                    /*while (ln != null && categoria == vln[0] && subcategoria == vln[1])
                    {
                        
                    }*/
                }
            }
            sr.Close();
            fs.Close();
        } 
        
        private void button1_Click(object sender, EventArgs e)
        {
            reporte();
        }
    }
}
